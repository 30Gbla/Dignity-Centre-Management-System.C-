#include "System.h"
#include <iostream>
#include <fstream>
using namespace std;

void showMenu() {
    cout << "\n===== DIGNITY CENTRE SYSTEM =====\n";
    cout << "1. Add Client\n2. Search Client\n3. Save & Exit\n";
    cout << "Enter choice: ";
}

void saveToFile(vector<Person>& clients) {
    ofstream file("data.txt");
    for (auto &p : clients)
        file << p.getName() << " " << p.getPhone() << "\n";
}

void loadFromFile(vector<Person>& clients) {
    ifstream file("data.txt");
    string name, phone;
    while (file >> name >> phone)
        clients.push_back(Person(name, phone));
}

void searchClient(vector<Person>& clients) {
    string input;
    cout << "Enter name or phone: ";
    cin >> input;
    bool found = false;

    for (auto &p : clients) {
        if (p.getName() == input || p.getPhone() == input) {
            p.display();
            found = true;
        }
    }

    if (!found)
        cout << "No record found.\n";
}
