#ifndef PERSON_H
#define PERSON_H

#include <string>
using namespace std;

class Person {
private:
    string name;
    string phone;

public:
    Person();
    Person(string n, string p);

    string getName();
    string getPhone();
    void display();
};

#endif
