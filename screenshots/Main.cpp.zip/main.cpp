#include <iostream>
#include <vector>
#include "System.h"
using namespace std;

int main() {
    vector<Person> clients;
    loadFromFile(clients);

    int choice;

    while (true) {
        showMenu();
        cin >> choice;

        if (choice == 1) {
            string name, phone;
            cout << "Enter name: ";
            cin >> name;
            cout << "Enter phone: ";
            cin >> phone;

            clients.push_back(Person(name, phone));
        }
        else if (choice == 2) {
            searchClient(clients);
        }
        else if (choice == 3) {
            saveToFile(clients);
            cout << "Saved. Exiting...\n";
            break;
        }
        else {
            cout << "Invalid choice\n";
        }
    }

    return 0;
}
