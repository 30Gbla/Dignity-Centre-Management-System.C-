#include "Person.h"
#include <iostream>
using namespace std;

Person::Person() {}

Person::Person(string n, string p) {
    name = n;
    phone = p;
}

string Person::getName() {
    return name;
}

string Person::getPhone() {
    return phone;
}

void Person::display() {
    cout << "Name: " << name << ", Phone: " << phone << endl;
}
