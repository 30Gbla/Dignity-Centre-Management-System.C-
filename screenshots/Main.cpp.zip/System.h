#ifndef SYSTEM_H
#define SYSTEM_H

#include <vector>
#include "Person.h"

void showMenu();
void saveToFile(vector<Person>& clients);
void loadFromFile(vector<Person>& clients);
void searchClient(vector<Person>& clients);

#endif
